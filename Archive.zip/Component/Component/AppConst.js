const AppConst = {
  AppName: 'CartPadle',
  rupeeSym: '\u20B9',
  inputPH_select_cat: 'Please Select Category',
  inputPH_enter_name: 'Name',
  inputPH_price: 'Price',
  inputPH_Discount_price: 'Discounted price',
  inputPH_unit: 'Unit',
  inputPH_bunch: 'Bunch',
  inputPH_detail: 'Detail1',
  btnTitleAddToCart: 'ADD TO CART',
  btnTitleUpdateToCart: 'UPDATE CART',
  btnTitleBuyNow: 'BUY NOW',
  btnDelete: 'DELETE',
};

export default AppConst;
