import {RESET_STORE} from './index.actions';
export const resetStore = () => {
  return {
    type: RESET_STORE,
  };
};
