export const DESTROY_SESSION = 'destroy_session';
