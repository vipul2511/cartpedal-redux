export const API_URL = 'https://www.cartpedal.com/';
